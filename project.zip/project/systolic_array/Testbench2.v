
`timescale 1ns/1ps

module tb_cnn;

    parameter W = 8;
    parameter AW = 24;
    parameter NIMG = 100;

    parameter DIR = "D:/Quartus/EE224/project/modelsim_data";

    reg clock, reset;
    reg [4*W-1:0] Ain, Bin;
    wire [16*AW-1:0] C;

    // Matrices used for storing input and expected values
    integer A_mat [0:700000];
    integer B_mat [0:40000];
    integer expected [0:600000];

    integer logits [0:NIMG*16-1];
    integer bias2 [0:15];
    integer labels [0:NIMG-1];
    integer expect_pred [0:NIMG-1];

    integer M, K, N;
    integer errors, total_errors;
    integer cycles, total_cycles;

    // Systolic array
    systolic_array #(.W(W), .W_accum(AW)) DUT (
        .clock(clock),
        .reset(reset),
        .Ain(Ain),
        .Bin(Bin),
        .C(C)
    );

    // Clock generation
    initial
    begin
        clock = 0;
        forever #5 clock = ~clock;
    end

    // Loading values from text files
    task load_file;
        input [8*80-1:0] fname;
        input integer count;
        input integer which;

        integer fd, i, value, rc;

        begin
            fd = $fopen(fname, "r");

            if(fd == 0)
            begin
                $display("ERROR: Cannot open file %0s", fname);
                $finish;
            end

            for(i=0; i<count; i=i+1)
            begin
                rc = $fscanf(fd, "%d", value);

                if(rc != 1)
                begin
                    $display("ERROR while reading file at index %0d", i);
                    $fclose(fd);
                    $finish;
                end

                if(which == 0)
                    A_mat[i] = value;
                else if(which == 1)
                    B_mat[i] = value;
                else
                    expected[i] = value;
            end

            $fclose(fd);
        end
    endtask


    // Running one layer of matrix multiplication
    task run_layer;
        input [8*16-1:0] name;

        integer mt, nt, t, i, j, index;
        integer got;
        integer fd, rc;

        reg [8*80-1:0] fname;

        begin

            // Reading matrix dimensions
            $sformat(fname, "%0s/%0s_dims.txt", DIR, name);

            fd = $fopen(fname, "r");

            if(fd == 0)
            begin
                $display("ERROR: Cannot open dimensions file");
                $finish;
            end

            rc = $fscanf(fd, "%d %d %d", M, K, N);
            $fclose(fd);

            if(rc != 3)
            begin
                $display("ERROR: Invalid dimensions file");
                $finish;
            end

            // Loading input matrix A
            $sformat(fname, "%0s/%0s_A.txt", DIR, name);
            load_file(fname, M*K, 0);

            // Loading input matrix B
            $sformat(fname, "%0s/%0s_B.txt", DIR, name);
            load_file(fname, K*N, 1);

            // Loading expected output matrix
            $sformat(fname, "%0s/%0s_golden.txt", DIR, name);
            load_file(fname, M*N, 2);

            errors = 0;
            cycles = 0;

            // Dividing matrices into 4x4 blocks
            for(mt=0; mt<M/4; mt=mt+1)
            begin
                for(nt=0; nt<N/4; nt=nt+1)
                begin

                    // Resetting the systolic array
                    @(negedge clock);

                    reset = 1;
                    Ain = 0;
                    Bin = 0;

                    cycles = cycles + 1;

                    // Feeding skewed inputs into the array
                    for(t=0; t<K+6; t=t+1)
                    begin
                        @(negedge clock);

                        reset = 0;

                        // Feeding rows of matrix A
                        for(i=0; i<4; i=i+1)
                        begin
                            index = t-i;

                            if(index >= 0 && index < K)
                                Ain[i*W +: W] =
                                    A_mat[(mt*4+i)*K+index];
                            else
                                Ain[i*W +: W] = 0;
                        end

                        // Feeding columns of matrix B
                        for(j=0; j<4; j=j+1)
                        begin
                            index = t-j;

                            if(index >= 0 && index < K)
                                Bin[j*W +: W] =
                                    B_mat[index*N+nt*4+j];
                            else
                                Bin[j*W +: W] = 0;
                        end

                        cycles = cycles + 1;

                    end

                    @(negedge clock);

                    // Checking the output matrix
                    for(i=0; i<4; i=i+1)
                    begin
                        for(j=0; j<4; j=j+1)
                        begin

                            got = $signed(C[(i*4+j)*AW +: AW]);

                            index = (mt*4+i)*N+nt*4+j;

                            // Storing final dense layer outputs
                            if(name == "dense2")
                            begin
                                logits[(mt*4+i)*16+nt*4+j] = got;
                            end

                            // Comparing simulation output with expected output
                            if(got !== expected[index])
                            begin
                                errors = errors + 1;

                                if(errors <= 5)
                                begin
                                    $display(
                                        "ERROR in %0s at tile(%0d,%0d), C[%0d][%0d]: Got=%0d Expected=%0d",
                                        name, mt, nt, i, j,
                                        got, expected[index]
                                    );
                                end
                            end

                        end
                    end

                end
            end

            total_errors = total_errors + errors;
            total_cycles = total_cycles + cycles;

            $display("----------------------------------------------");
            $display("Layer: %0s", name);
            $display("Matrix A: %0d x %0d", M, K);
            $display("Matrix B: %0d x %0d", K, N);
            $display("Number of tiles: %0d", (M/4)*(N/4));
            $display("Clock cycles: %0d", cycles);
            $display("Mismatches: %0d", errors);
            $display("----------------------------------------------");

        end
    endtask


    // Main simulation
    initial
    begin

        clock = 0;
        reset = 1;
        Ain = 0;
        Bin = 0;

        total_errors = 0;
        total_cycles = 0;

        // Running all four CNN layers
        run_layer("conv1");
        run_layer("conv2");
        run_layer("dense1");
        run_layer("dense2");


        // Final classification
        begin : classification

            integer i, j;
            integer fd, rc;
            integer best, bestv;
            integer correct, agree;

            reg [8*80-1:0] fname;

            // Reading bias values of dense2
            $sformat(fname, "%0s/b_dense2.txt", DIR);

            fd = $fopen(fname, "r");

            if(fd == 0)
            begin
                $display("ERROR: Cannot open dense2 bias file");
                $finish;
            end

            for(i=0; i<10; i=i+1)
                rc = $fscanf(fd, "%d", bias2[i]);

            $fclose(fd);

            // Reading actual labels
            $sformat(fname, "%0s/test_labels_100.txt", DIR);

            fd = $fopen(fname, "r");

            if(fd == 0)
            begin
                $display("ERROR: Cannot open labels file");
                $finish;
            end

            for(i=0; i<NIMG; i=i+1)
                rc = $fscanf(fd, "%d", labels[i]);

            $fclose(fd);

            // Reading expected predictions
            $sformat(fname, "%0s/expected_pred_100.txt", DIR);

            fd = $fopen(fname, "r");

            if(fd == 0)
            begin
                $display("ERROR: Cannot open predictions file");
                $finish;
            end

            for(i=0; i<NIMG; i=i+1)
                rc = $fscanf(fd, "%d", expect_pred[i]);

            $fclose(fd);

            correct = 0;
            agree = 0;

            // Finding the predicted class using argmax
            for(i=0; i<NIMG; i=i+1)
            begin

                best = 0;
                bestv = logits[i*16] + bias2[0];

                for(j=1; j<10; j=j+1)
                begin
                    if(logits[i*16+j] + bias2[j] > bestv)
                    begin
                        bestv = logits[i*16+j] + bias2[j];
                        best = j;
                    end
                end

                if(best == labels[i])
                    correct = correct + 1;

                if(best == expect_pred[i])
                    agree = agree + 1;

                $display(
                    "Image %0d: Label=%0d Predicted=%0d",
                    i, labels[i], best
                );

            end

            // Final results
            $display("\n================================================");

            $display(
                "Total matrix multiplication mismatches: %0d",
                total_errors
            );

            $display(
                "Total clock cycles: %0d",
                total_cycles
            );

            $display(
                "Systolic array test accuracy: %0d / %0d (%0d %%)",
                correct, NIMG, correct*100/NIMG
            );

            $display(
                "Agreement with NumPy model: %0d / %0d",
                agree, NIMG
            );

            $display("================================================");

        end

        $display("\nSimulation completed.");
        $finish;

    end

endmodule
