module tb_systolic_array;

    parameter W = 8;
    parameter AW = 24;
    parameter N = 4;
    parameter K = 8;  // Change to 4 for Part B(i)

    reg clock, reset;
    reg [4*W-1:0] Ain, Bin;
    wire [16*AW-1:0] C;

    integer A_mat [0:3][0:K-1];
    integer B_mat [0:K-1][0:3];
    integer expected [0:3][0:3];

    integer i, j, k, t, index;

    systolic_array #(.W(W), .W_accum(AW)) DUT (
        .clock(clock),
        .reset(reset),
        .Ain(Ain),
        .Bin(Bin),
        .C(C)
    );

    // Clock generation
    initial
    begin
        clock = 0;
        forever #5 clock = ~clock;
    end

    // Initial values and reset
    initial
    begin
        reset = 1;
        Ain = 0;
        Bin = 0;

        for(i=0; i<4; i=i+1)
        begin
            for(j=0; j<K; j=j+1)
            begin
                A_mat[i][j] = i + 2*j + 1;
                B_mat[j][i] = j + 2*i + 1;
            end
        end

        for(i=0; i<4; i=i+1)
        begin
            for(j=0; j<4; j=j+1)
            begin
                expected[i][j] = 0;

                for(k=0; k<K; k=k+1)
                begin
                    expected[i][j] =
                    expected[i][j] + A_mat[i][k]*B_mat[k][j];
                end
            end
        end

        repeat(2) @(posedge clock);
        @(negedge clock);
        reset = 0;

        // Feeding inputs into the systolic array
        for(t=0; t<K+2*N-2; t=t+1)
        begin
            @(negedge clock);

            for(i=0; i<4; i=i+1)
            begin
                index = t-i;

                if(index >= 0 && index < K)
                    Ain[i*W +: W] = A_mat[i][index];
                else
                    Ain[i*W +: W] = 0;
            end

            for(j=0; j<4; j=j+1)
            begin
                index = t-j;

                if(index >= 0 && index < K)
                    Bin[j*W +: W] = B_mat[index][j];
                else
                    Bin[j*W +: W] = 0;
            end

            @(posedge clock);
            #1;

            $display("Cycle = %0d, Ain = %h, Bin = %h",
                      t+1, Ain, Bin);
        end

        // Display final output matrix
        $display("\nExpected Matrix:");
        for(i=0; i<4; i=i+1)
        begin
            $display("%0d %0d %0d %0d",
                expected[i][0], expected[i][1],
                expected[i][2], expected[i][3]);
        end

        $display("\nOutput Matrix from Systolic Array:");
        for(i=0; i<4; i=i+1)
        begin
            for(j=0; j<4; j=j+1)
            begin
                $write("%0d ",
                    $signed(C[(i*4+j)*AW +: AW]));
            end
            $display("");
        end

        // Comparing expected and actual outputs
        for(i=0; i<4; i=i+1)
        begin
            for(j=0; j<4; j=j+1)
            begin
                if($signed(C[(i*4+j)*AW +: AW]) != expected[i][j])
                begin
                    $display("ERROR at C[%0d][%0d]", i, j);
                end
            end
        end

        $display("\nSimulation completed.");
        $finish;
    end

endmodule
